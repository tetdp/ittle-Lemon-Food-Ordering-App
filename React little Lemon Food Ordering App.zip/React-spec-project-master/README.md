to run this app you need to have node.js, npm and expo installed.

go to your local coding enviorment and run "npm i" and then run "npx expo start" to run this code, use the qr code or your local emulator
